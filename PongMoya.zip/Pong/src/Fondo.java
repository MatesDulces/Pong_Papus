import java.awt.EventQueue;
import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.Timer;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Fondo {
    private JFrame frame;
    private JPanel Player1;
    private JPanel Player2;
    private JPanel Bola;
    private int playerSpeed = 10;
    private double bolaSpeedX = 5;
    private double bolaSpeedY = 5;
    private Timer resetTimer;
    private int puntosPlayer1 = 0;
    private int puntosPlayer2 = 0;
    private JLabel scoreLabel;
    private double velocityIncrement = 0.2; // Incremento de velocidad por golpe
    private double maxSpeed = 15; // Velocidad máxima de la bola
   
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Fondo window = new Fondo();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Fondo() {
        initialize();
        resetBola();
    }

    private void initialize() {
        frame = new JFrame();
        frame.getContentPane().setBackground(new Color(0, 0, 0));
        frame.getContentPane().setLayout(null);
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        Player1 = new JPanel();
        Player1.setBounds(10, 100, 10, 50);
        frame.getContentPane().add(Player1);
       
        Player2 = new JPanel();
        Player2.setBounds(415, 100, 10, 50);
        frame.getContentPane().add(Player2);

        Bola = new JPanel();
        Bola.setBounds(206, 124, 10, 10);
        frame.getContentPane().add(Bola);

        scoreLabel = new JLabel("Jugador 1: 0 | Jugador 2: 0");
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 16));
        scoreLabel.setForeground(Color.WHITE);
        scoreLabel.setBounds(110, 11, 219, 20);
        frame.getContentPane().add(scoreLabel);

        frame.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                movePlayer(e);
            }
            @Override
            public void keyReleased(KeyEvent e) {}
        });

        frame.setFocusable(true);

        Timer timer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                moverBola();
            }
        });
        timer.start();
    }

    private void checkCollisions() {
        int bolaX = Bola.getX();
        int bolaY = Bola.getY();
        int bolaWidth = Bola.getWidth();
        int bolaHeight = Bola.getHeight();

        int player1X = Player1.getX();
        int player1Y = Player1.getY();
        int player1Width = Player1.getWidth();
        int player1Height = Player1.getHeight();

        int player2X = Player2.getX();
        int player2Y = Player2.getY();
        int player2Width = Player2.getWidth();
        int player2Height = Player2.getHeight();

        // Colisión con el jugador 1
        if (bolaX <= player1X + player1Width &&
            bolaY + bolaHeight >= player1Y &&
            bolaY <= player1Y + player1Height) {

            bolaSpeedX = Math.abs(bolaSpeedX);

            // Calcular el punto de impacto relativo en la paleta
            double relativeImpact = ((double) (bolaY + bolaHeight / 2) - (player1Y + player1Height / 2)) / (player1Height / 2);

            // Ajustar la velocidad vertical de la bola basado en el impacto
            bolaSpeedY += relativeImpact * 2; // Multiplica por un factor para ajustar la sensibilidad
            incrementarVelocidad();
        }

        // Colisión con el jugador 2
        if (bolaX + bolaWidth >= player2X &&
            bolaY + bolaHeight >= player2Y &&
            bolaY <= player2Y + player2Height) {

            bolaSpeedX = -Math.abs(bolaSpeedX);

            // Calcular el punto de impacto relativo en la paleta
            double relativeImpact = ((double) (bolaY + bolaHeight / 2) - (player2Y + player2Height / 2)) / (player2Height / 2);

            // Ajustar la velocidad vertical de la bola basado en el impacto
            bolaSpeedY += relativeImpact * 2; // Multiplica por un factor para ajustar la sensibilidad
            incrementarVelocidad();
        }
    }

    private void incrementarVelocidad() {
        double speed = Math.sqrt(bolaSpeedX * bolaSpeedX + bolaSpeedY * bolaSpeedY);
        if (speed < maxSpeed) {
            double factor = (speed + velocityIncrement) / speed;
            bolaSpeedX *= factor;
            bolaSpeedY *= factor;
        }
    }

    private void movePlayer(KeyEvent e) {
        int key = e.getKeyCode();
        int y = Player1.getY();
        if (key == KeyEvent.VK_W && y > 0) {
            Player1.setLocation(Player1.getX(), y - playerSpeed);
        } else if (key == KeyEvent.VK_S && y < 210) {
            Player1.setLocation(Player1.getX(), y + playerSpeed);
        }
        int y2 = Player2.getY();
        if (key == KeyEvent.VK_UP && y2 > 0) {
            Player2.setLocation(Player2.getX(), y2 - playerSpeed);
        } else if (key == KeyEvent.VK_DOWN && y2 < 210) {
            Player2.setLocation(Player2.getX(), y2 + playerSpeed);
        }
    }

    private void moverBola() {
        int x = Bola.getX();
        int y = Bola.getY();

        x += (int) bolaSpeedX;
        y += (int) bolaSpeedY;

        if (x <= 0) {
            puntosPlayer2++;
            actualizarPuntuacion();
            resetBola();
            return;
        } else if (x >= 425) {
            puntosPlayer1++;
            actualizarPuntuacion();
            resetBola();
            return;
        }
        if (y <= 0 || y >= 250) {
            bolaSpeedY = -bolaSpeedY;
        }

        Bola.setLocation(x, y);
       
        checkCollisions();
    }

    private void actualizarPuntuacion() {
        scoreLabel.setText("Jugador 1: " + puntosPlayer1 + " | Jugador 2: " + puntosPlayer2);
    }

    private void resetBola() {
        bolaSpeedX = 0;
        bolaSpeedY = 0;

        int initialX = 206;
        int initialY = 124;
    
        Bola.setLocation(initialX, initialY);
    
        resetTimer = new Timer(500, e -> lanzarBola());
        resetTimer.setRepeats(false);
        resetTimer.start();
    }

    private void lanzarBola() {
        bolaSpeedX = (Math.random() > 0.5) ? 5 : -5;
        bolaSpeedY = (Math.random() > 0.5) ? 5 : -5;
    }
}
